<template>
	<div class="container">
		<navigation-component />
		<div class="mt-5">
			<router-view />
		</div>
	</div>
</template>

<script>
	import NavigationComponent from "./components/bs-nav/NavigationComponent.vue";
	export default {
		components: { NavigationComponent },
		name: "AppComponent",
	};
</script>

