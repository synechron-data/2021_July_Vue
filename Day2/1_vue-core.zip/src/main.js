import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';

import Vue from 'vue';
import App from './App.vue';
import changeContent from './directives/cc.directive';
import highlightDirective from './directives/highlight.directive';

Vue.config.productionTip = false;

// Global Registration
Vue.directive('cc', changeContent);
Vue.directive('highlight', highlightDirective);

Vue.filter('JSON', function (value) {
  return JSON.stringify(value);
});

new Vue({
  render: (createElement) => createElement(App)
}).$mount("#app");