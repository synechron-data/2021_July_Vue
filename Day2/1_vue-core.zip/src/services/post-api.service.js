const url = "https://jsonplaceholder.typicode.com/posts";

const postAPIService = {
    getAllPosts: function () {
        return new Promise((resolve, reject) => {
            fetch(url).then(response => {
                response.json().then(data => {
                    setTimeout(() => {
                        resolve(data);
                    }, 5000);
                }).catch(err => {
                    // Error Logging
                    console.error(err);
                    reject("Parsing Error...");
                });
            }).catch(err => {
                // Error Logging
                console.error(err);
                reject("Communication Error...");
            });
        });
    }
};

export default postAPIService;

// XMLHTTPRequest (XHR)
// Fetch
// jQuery AJAX
// Axios
// vue-resource