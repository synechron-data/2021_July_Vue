<template>
	<div>
		<h2 class="text-info">Component with Internal Data</h2>
		<h2 class="text-info">Hello, {{ name }}</h2>
		<h2 class="text-info" v-text="name">Hello</h2>
		<h2 class="text-info">Hello, <span v-text="name"></span></h2>
		<h2 class="text-info" v-html="name">Hello</h2>

		<h2 class="text-success" v-show="flag">Hello, I am hidden</h2>
		<h2 class="text-success" v-bind:hidden="!flag">Hello, I am hidden</h2>
		<h2 class="text-success" :hidden="!flag">Hello, I am hidden</h2>

		<h2 class="text-success" v-if="flag">Hello, I am hidden</h2>

		<h2 class="text-primary">List Rendering</h2>
		<ul class="list-group">
			<li class="list-group-item" v-for="e in employees" v-bind:key="e.id">
				{{e.name}}
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		name: "ComponentWithData",
		data: function () {
			return {
				name: "Synechron",
				flag: false,
				employees: [
					{ id: 1, name: "Manish" },
					{ id: 2, name: "Abhijeet" },
					{ id: 3, name: "Ramakant" },
					{ id: 4, name: "Subodh" },
					{ id: 5, name: "Abhishek" },
				],
			};
		},
	};
</script>