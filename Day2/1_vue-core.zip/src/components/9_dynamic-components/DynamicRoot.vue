<template>
	<div>
		<!-- <component-one />
		<component-two /> -->

		<!-- <button class="btn btn-primary" @click="toggle">Toggle</button>
		<hr />
		<component v-bind:is="comp" /> -->

		<button class="btn btn-primary" @click="toggle">Toggle</button>
		<hr />
		<keep-alive>
			<component v-bind:is="comp" />
		</keep-alive>
	</div>
</template>

<script>
	import ComponentOne from "./ComponentOne.vue";
	import ComponentTwo from "./ComponentTwo.vue";
	export default {
		name: "DynamicRoot",
		components: { ComponentOne, ComponentTwo },
		data: function () {
			return {
				comp: ComponentOne,
			};
		},
		methods: {
			toggle() {
				if (this.comp === ComponentOne) {
					this.comp = ComponentTwo;
				} else {
					this.comp = ComponentOne;
				}
			},
		},
	};
</script>