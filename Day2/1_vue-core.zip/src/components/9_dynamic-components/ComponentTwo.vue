<template>
    <div>
        <h1 class="text-success">Hello from Component Two</h1>    
    </div>
</template>

<script>
    export default {
        name: "ComponentTwo",
        destroyed () {
            console.log("ComponentTwo Destroyed");
        },
    }
</script>