<template>
	<div>
		<h1 class="text-primary">Understanding - Handling Events</h1>
		<div class="row">
			<div class="col">
				<button class="btn btn-primary btn-block" v-on:click="hello">
					Click
				</button>
			</div>
			<div class="col">
				<button class="btn btn-primary btn-block" @click="hello">Click</button>
			</div>
			<div class="col">
				<button class="btn btn-primary btn-block" @click="handleClick">
					Click
				</button>
			</div>
			<div class="col">
				<button class="btn btn-primary btn-block" @click="handleClick()">
					Click
				</button>
			</div>
			<div class="col">
				<button
					class="btn btn-primary btn-block"
					@click="handleClick('Hello from Template')"
				>
					Click
				</button>
			</div>
		</div>

		<hr />
		<h2>Event Object and Passing Arguments</h2>
		<div class="row">
			<div class="col">
				<a href="#" @click="handleClick('Hello from template')">Click Me</a>
			</div>
			<div class="col">
				<a
					href="https://www.google.com"
					@click="handleClick('Hello from template')"
					>Click Me</a
				>
			</div>
			<div class="col">
				<a href="https://www.google.com" @click="anchorClick1">Click Me</a>
			</div>
			<div class="col">
				<a href="https://www.google.com" @click="anchorClick1($event)"
					>Click Me</a
				>
			</div>
			<div class="col">
				<a
					href="https://www.google.com"
					@click="anchorClick2('Hello from template', $event)"
					>Click Me</a
				>
			</div>
		</div>

		<hr />
		<h2>Event Modifiers</h2>
		<div class="row">
			<div class="col">
				<a
					href="https://www.google.com"
					@click.prevent="handleClick('Hello from template')"
					>Click Me</a
				>
			</div>
			<div class="col">
				<a
					href="https://www.google.com"
					@click.passive="handleClick('Hello from template')"
					>Click Me</a
				>
			</div>
			<div class="col">
				<a
					href="https://www.google.com"
					@click.prevent.once="handleClick('Hello from template')"
					>Click Me</a
				>
			</div>
		</div>

		<hr />
		<h2>Key Modifiers</h2>
		<div class="row">
			<div class="col">
				<input type="text" @keyup="onKeyUp" />
			</div>
			<div class="col">
				<input type="text" @keyup.enter="onEnter" />
			</div>
            <div class="col">
				<h2 class="text-success" @click="onClick">Do Something when user do, click</h2>
			</div>
			<div class="col">
				<h2 class="text-success" @click.ctrl="onClick">Do Something when user do, ctrl + click</h2>
			</div>
            <div class="col">
				<h2 class="text-success" @click.ctrl.exact="onClick">Do Something when user do, ctrl + click (No Other Keys)</h2>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "EventComponent",
		methods: {
			hello() {
				console.log("Hello from Button Click");
			},
			handleClick(msg) {
				// If we donot pass any data in function call,
				// msg will be treated as event Object
				console.log("Hello from Handle Click");
				console.log("Msg: ", msg);
			},
			anchorClick1(e) {
				console.log("Hello from Anchor Click One");
				e.preventDefault();
			},
			anchorClick2(msg, e) {
				console.log("Hello from Anchor Click Two");
				console.log("Msg: ", msg);
				e.preventDefault();
			},
			onKeyUp() {
				console.log("Key Up Event");
			},
			onEnter() {
				console.log("Enter Key Pressed");
			},
            onClick(){
                console.log("Click, done on the h2 tag");
            }
		},
	};
</script>