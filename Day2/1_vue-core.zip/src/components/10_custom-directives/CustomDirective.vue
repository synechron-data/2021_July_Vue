<template>
	<div>
		<h2 class="text-info">Custom Directives</h2>
		<h3 v-cc></h3>
		<p v-cc></p>
		<span v-cc></span>
		<div v-cc></div>

		<ul class="list-group">
			<!-- <li v-for="e in employees" v-bind:key="e.id" v-highlight class="list-group-item"> -->
			<li v-for="e in employees" v-bind:key="e.id" v-highlight="'skyblue'" class="list-group-item">
                {{e.name}}
            </li>
		</ul>
	</div>
</template>

<script>
	export default {
		name: "CustomDirective",
		data() {
			return {
				employees: [
					{ id: 1, name: "Manish" },
					{ id: 2, name: "Abhijeet" },
					{ id: 3, name: "Ramakant" },
					{ id: 4, name: "Subodh" },
					{ id: 5, name: "Abhishek" },
				],
			};
		},
	};
</script>