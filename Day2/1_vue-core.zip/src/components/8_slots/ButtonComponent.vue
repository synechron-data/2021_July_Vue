<template>
	<button class="btn">
		<slot>Click Me</slot>
	</button>
</template>

<script>
	export default {
		name: "ButtonComponent"
	};
</script>

<style lang="scss" scoped>
	$primary-color: #66615b;

	.btn {
		border: 2px solid $primary-color;
		padding: 10px;
		font-size: 16px;
		border-radius: 20px;
		color: $primary-color;

		&:hover {
			background-color: $primary-color;
			color: white;
		}
	}
</style>