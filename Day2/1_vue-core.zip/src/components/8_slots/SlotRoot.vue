<template>
	<div>
		<List :items="listItems">
			<div slot-scope="row" class="list-group-item">
				<span class="badge badge-primary">
					{{ row.item.id }}
				</span>
				{{ row.item.name }}
                <i class="bi bi-person"></i>
			</div>
		</List>

		<button-component />

		<button-component> Click to Change </button-component>

		<button-component>
			<i class="bi bi-alarm"></i>
		</button-component>

		<button-component>
			<i class="bi bi-person"></i>
			Profile
		</button-component>

		<Frame />
		<Frame></Frame>
		<Frame>
			<img src="../../assets/logo.png" />
		</Frame>

		<hr />
		<titled-frame />
		<titled-frame>
			<template v-slot:title>Vue JS</template>
			<img src="../../assets/logo.png" />
		</titled-frame>
	</div>
</template>

<script>
	import ButtonComponent from "./ButtonComponent.vue";
	import Frame from "./Frame.vue";
	import List from "./List.vue";
	import TitledFrame from "./TitledFrame.vue";
	export default {
		components: { ButtonComponent, Frame, TitledFrame, List },
		name: "SlotRoot",
		data: function () {
			return {
				listItems: [
					{ id: 1, name: "Manish" },
					{ id: 2, name: "Abhijeet" },
					{ id: 3, name: "Ramakant" },
					{ id: 4, name: "Subodh" },
				],
			};
		},
	};
</script>