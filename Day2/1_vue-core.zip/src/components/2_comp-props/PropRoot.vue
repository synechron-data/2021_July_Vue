<template>
	<div>
		<!-- <component-with-props
			:id="1"
			:name="'Manish'"
			:address="{ city: 'Pune', state: 'MH' }"
		/> -->
		<!-- <component-with-props
			:name="'Manish'"
			:address="{ city: 'Pune', state: 'MH' }"
			:friends="['Abhijeet', 'Ramakant']"
			:greet="() => { alert("From the Parent Component"); }"
		/> -->
        <component-with-props
			:name="'Manish'"
			:address="{ city: 'Pune', state: 'MH' }"
			:friends="['Abhijeet', 'Ramakant']"
		/>
	</div>
</template>

<script>
	import ComponentWithProps from "./ComponentWithProps.vue";
	export default {
		name: "PropRoot",
		components: { ComponentWithProps },
	};
</script>