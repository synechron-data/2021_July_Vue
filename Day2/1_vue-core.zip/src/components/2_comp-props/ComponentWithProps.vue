<template>
	<div>
		<h1 class="text-info">Component With Props</h1>
		<h2>Id: {{ id }}</h2>
		<h2>Name: {{ name }}</h2>
		<h2>Address: {{ address }}</h2>
		<h2>Friends: {{ friends }}</h2>
		<hr />
		<h2>Num: {{ num }}</h2>
		<h2>Computed Num: {{ numDouble }}</h2>
        <h2>Computed city: {{ city }}</h2>
		<h2>Computed state: {{ state }}</h2>
	</div>
</template>

<script>
	export default {
		name: "ComponentWithProps",
		// props: ["id", "name", "address"],
		props: {
			// id: {
			// 	type: Number,
			//  required: true
			// },
			id: {
				type: Number,
				default: 0,
			},
			name: {
				type: String,
				required: true,
			},
			address: {
				type: Object,
				required: true,
				validator: (obj) => {
					// Write a logic to verify object
					// console.log(obj);
					Object.keys(obj).forEach((key) => {
						// Write a logic to verify key
						console.log(key);
					});
					return true;
				},
			},
			friends: {
				type: Array,
				required: true,
			},
			greet: {
				type: Function,
				default: function () {
					alert("From the Component");
				},
			},
		},
		data: function () {
			return {
				num: 20,
			};
		},
		computed: {
			numDouble: function () {
				return this.num * 2;
			},
			city() {
				return `Your city is ${this.address.city}`;
			},
			state() {
				return `Your state is ${this.address.state}`;
			},
		},
	};
</script>