<template>
	<div class="container">
		<!-- <component-with-data /> -->
		<!-- <prop-root /> -->
		<!-- <behavior-root /> -->
		<!-- <event-component /> -->
		<!-- <binding-component /> -->
		<!-- <calculator /> -->
		<!-- <counter-assignment /> -->
		<!-- <slot-root /> -->
		<!-- <dynamic-root /> -->
		<!-- <custom-directive /> -->
		<!-- <filter-demo /> -->
		<ajax-component />
	</div>
</template>

<script>
	/* eslint-disable */
	import ComponentWithData from "./components/1_comp-data/ComponentWithData.vue";
	import PropRoot from "./components/2_comp-props/PropRoot.vue";
	import BehaviorRoot from "./components/3_comp-methods/BehaviorRoot.vue";
	import EventComponent from "./components/4_event-handling/EventComponent.vue";
	import BindingComponent from "./components/5_two-way-binding/BindingComponent.vue";
	import Calculator from "./components/6_calculator-assignment/Calculator.vue";
	import CounterAssignment from "./components/7_counter-assignment/CounterAssignment.vue";
	import SlotRoot from "./components/8_slots/SlotRoot.vue";
	import DynamicRoot from "./components/9_dynamic-components/DynamicRoot.vue";
	import CustomDirective from "./components/10_custom-directives/CustomDirective.vue";
	import FilterDemo from "./components/11_filters/FilterDemo.vue";
	import AjaxComponent from "./components/12_ajax-calls/AjaxComponent.vue";

	export default {
		components: {
			ComponentWithData,
			PropRoot,
			BehaviorRoot,
			EventComponent,
			BindingComponent,
			Calculator,
			CounterAssignment,
			SlotRoot,
			DynamicRoot,
			CustomDirective,
			FilterDemo,
			AjaxComponent,
		},
		name: "AppComponent",
	};
</script>