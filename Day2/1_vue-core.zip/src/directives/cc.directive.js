const changeContent = {
    bind(el) {
        el.innerHTML = "Content Added By Custom Directive";
    }
};

export default changeContent;