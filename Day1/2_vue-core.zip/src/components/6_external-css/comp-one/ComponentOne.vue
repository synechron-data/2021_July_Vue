<template>
	<div>
		<h1 class="text-info">Hello from Component One</h1>
		<h2 class="card1">From Component One</h2>
	</div>
</template>

<script>
	export default {
		name: "ComponentOne",
	};
</script>

<style>
	@import "./ComponentOne.css";
</style>