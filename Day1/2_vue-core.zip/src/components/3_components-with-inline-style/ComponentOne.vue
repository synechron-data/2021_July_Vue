<template>
	<div>
		<h1 class="text-info">Hello from Component One</h1>
		<h2 style="margin: 1em; padding-left: 0; border: 2px solid blue">
			From Component One
		</h2>
		<h2 v-bind:style="myStyles">From Component One</h2>
	</div>
</template>

<script>
	export default {
		name: "ComponentOne",
		data: function () {
			return {
				myStyles: {
					margin: "1em",
					"padding-left": 0,
					border: "2px solid blue",
				},
			};
		},
	};
</script>