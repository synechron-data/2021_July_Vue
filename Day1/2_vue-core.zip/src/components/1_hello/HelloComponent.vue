<template>
	<div>
		<h1 class="text-primary">Hello World</h1>
	</div>
</template>

<script>
	export default {
		name: "HelloComponent",
	};
</script>