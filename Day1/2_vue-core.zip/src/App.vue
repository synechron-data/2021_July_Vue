<template>
	<div class="container">
		<component-one />
		<component-two />
	</div>
</template>

<script>
	// import ComponentOne from "./components/2_multi-components/ComponentOne.vue";
	// import ComponentTwo from "./components/2_multi-components/ComponentTwo.vue";

	// import ComponentOne from "./components/3_components-with-inline-style/ComponentOne.vue";
	// import ComponentTwo from "./components/3_components-with-inline-style/ComponentTwo.vue";

	// import ComponentOne from "./components/4_component-with-css/ComponentOne.vue";
	// import ComponentTwo from "./components/4_component-with-css/ComponentTwo.vue";

	// import ComponentOne from "./components/5_component-with-css-modules/ComponentOne.vue";
	// import ComponentTwo from "./components/5_component-with-css-modules/ComponentTwo.vue";

	// import ComponentOne from "./components/6_external-css/comp-one/ComponentOne.vue";
	// import ComponentTwo from "./components/6_external-css/comp-two/ComponentTwo.vue";

	import ComponentOne from "./components/7_external-css-css-modules/comp-one/ComponentOne.vue";
	import ComponentTwo from "./components/7_external-css-css-modules/comp-two/ComponentTwo.vue";

	export default {
		components: { ComponentOne, ComponentTwo },
		name: "AppComponent",
	};
</script>