/* eslint-disable */

// ------------------- Inline the Template
// import Vue from 'vue';
// Vue.config.productionTip = false;

// Replace the element with the template
// // Enable runtimeCompiler: true in vue.config.js (Include Runtime and Compiler both in the build)
// // This will be required when we write templates in string format
// new Vue({
//   el: '#app',
//   template: `
//     <h1>
//       Hello from Main Vue
//     </h1>
//   `
// });

// // ------------------- Local Components

// import Vue from 'vue';
// Vue.config.productionTip = false;

// // Local Variable representing the Component
// const GreetingComponent = {
//   name: "GreetingComponent",
//   template: `
//     <h1>
//       Hello from Greeting Component
//     </h1>
//   `
// };

// // Replace the element with the template
// new Vue({
//   el: '#app',
//   template: `
//     <div id="my-app">
//       <!-- <GreetingComponent />
//       <greetingComponent />
//       <greeting-component /> -->

//       <!-- Using Identifier -->
//       <gComp />
//       <g-comp />
//     </div>
//   `,
//   // components: { GreetingComponent }   // Local Component Registration
//   components: { 
//     'gComp': GreetingComponent          // Local Component Registration with identifier
//   }   
// });

// ------------------- Global Components

// import Vue from 'vue';
// Vue.config.productionTip = false;

// // Global Component

// // If you registering a component using small case name, you can use it only using <smallcase/>
// // Vue.component("greetingcomponent", {
// //   template: `
// //     <h1>
// //       Hello from Global Greeting Component
// //     </h1>
// //   `
// // });

// // If you registering a component using PascalCase name, you can use it as <PascalCase/> or <camelCase/> or <kebab-case/>
// // Vue.component("GreetingComponent", {
// //   template: `
// //     <h1>
// //       Hello from Global Greeting Component
// //     </h1>
// //   `
// // });

// // If you registering a component using camelCase name, you can use it as <camelCase/> or <kebab-case/>
// // Vue.component("greetingComponent", {
// //   template: `
// //     <h1>
// //       Hello from Global Greeting Component
// //     </h1>
// //   `
// // });

// // If you registering a component using kebabCase name, you can use it as <kebab-case/>
// Vue.component("greeting-component", {
//   template: `
//     <h1>
//       Hello from Global Greeting Component
//     </h1>
//   `
// });

// // Replace the element with the template
// new Vue({
//   el: '#app',
//   template: `
//     <div id="my-app">
//       <!-- <greetingcomponent /> -->
//       <!-- <GreetingComponent /> -->
//       <GreetingComponent />
//       <greetingComponent />
//       <greeting-component />
//     </div>
//   `
// });

// ------------------------------------------------------------------

// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// new Vue({
//   el: '#app',
//   template: `
//     <div id="my-app">
//       <hello-component />
//     </div>
//   `,
//   components: {
//     'hello-component': HelloComponent
//   }
// });

// ------------------------------------------------------------------ Pre Compiled Templates
// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// // var vm = new Vue({
// //   render: function (createElement) {
// //     return createElement(HelloComponent);
// //   }
// // });

// // // console.log(vm);
// // vm.$mount("#app");

// // new Vue({
// //   render: function (createElement) {
// //     return createElement(HelloComponent);
// //   }
// // }).$mount("#app");

// // new Vue({
// //   render: (createElement) => createElement(HelloComponent)
// // }).$mount("#app");

// new Vue({
//   render: (h) => h(HelloComponent)
// }).$mount("#app");

// ----------------------------
// import Vue from 'vue';
// import Hello from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// new Vue({
//   render: (h) => h(Hello)
// }).$mount("#app");

// // -----------------------------
// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// new Vue({
//   render: (createElement) => createElement(HelloComponent)
// }).$mount("#app");

// // ----------------------------- Using Bootstrap 4 CSS 
// // npm i bootstrap@4 jquery popper.js
// // import 'bootstrap';
// // import 'bootstrap/dist/css/bootstrap.min.css';

// // To include .scss files
// // npm i -D node-sass@4 sass-loader@10
// import 'bootstrap';
// import 'bootstrap/scss/bootstrap.scss';

// import Vue from 'vue';
// import HelloComponent from './components/1_hello/HelloComponent.vue';

// Vue.config.productionTip = false;

// new Vue({
//   render: (createElement) => createElement(HelloComponent)
// }).$mount("#app");

// // ----------------------------- Using Multi Components
// import 'bootstrap';
// import 'bootstrap/scss/bootstrap.scss';

// import Vue from 'vue';
// import ComponentOne from './components/2_multi-components/ComponentOne.vue';
// import ComponentTwo from './components/2_multi-components/ComponentTwo.vue';

// Vue.config.productionTip = false;

// new Vue({
//   render: (createElement) => createElement(ComponentOne)
// }).$mount("#c1");

// new Vue({
//   render: (createElement) => createElement(ComponentTwo)
// }).$mount("#c2");

// ----------------------------- Using One Root Components
import 'bootstrap';
import 'bootstrap/scss/bootstrap.scss';

import Vue from 'vue';
import App from './App.vue';

Vue.config.productionTip = false;

new Vue({
  render: (createElement) => createElement(App)
}).$mount("#app");